#!/bin/bash
#

IPLDIR=/usr/local/ipLocation/
CEXE=ipLocation
LOG=${IPLDIR}ipLocation.log

function start()
{
        t="nohup $IPLDIR$CEXE > $LOG 2>&1 &"
        str=$(ps -ef |grep -v 'grep' | grep '/ipLocation/ipLocation' | awk '{printf ("%d ",$2)}')

        if [ ! -n "$str" ]; then
                echo "startup ..."
                eval $t
	else
		echo "running..."
        fi
}

start

